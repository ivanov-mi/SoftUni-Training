# This an ASP.NET Core MongoDB repository pattern implementation.

## It was created for a NoSQL databases course in SoftUni.

## It is a good starting point to use the MongoDB C# driver in your projects :) 