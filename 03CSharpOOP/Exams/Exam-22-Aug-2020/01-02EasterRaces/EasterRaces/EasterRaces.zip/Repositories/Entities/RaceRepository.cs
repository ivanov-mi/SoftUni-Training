﻿namespace EasterRaces.Repositories.Entities
{
    using EasterRaces.Models.Races.Contracts;

    public class RaceRepository : Repository<IRace>
    {
        public override void Add(IRace model)
        {
            this.collection.Add(model.Name, model);
        }

        public override IRace GetByName(string name)
            => this.collection[name];

        public override bool Remove(IRace model) 
            => this.collection.Remove(model.Name);
    }
}
