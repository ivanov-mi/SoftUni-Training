﻿namespace EasterRaces.Repositories.Entities
{
    using System.Collections.Generic;
    using System.Linq;
    using EasterRaces.Repositories.Contracts;

    public abstract class Repository<T> : IRepository<T>
    {
        public Dictionary<string, T> collection;

        protected Repository()
        {
            this.collection = new Dictionary<string, T>();
        }

        public abstract void Add(T model);

        public IReadOnlyCollection<T> GetAll() 
            => this.collection.Values.ToArray();

        public abstract T GetByName(string name);

        public abstract bool Remove(T model);
    }
}
