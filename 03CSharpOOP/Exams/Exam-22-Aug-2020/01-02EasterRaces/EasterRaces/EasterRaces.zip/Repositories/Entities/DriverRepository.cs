﻿namespace EasterRaces.Repositories.Entities
{
    using EasterRaces.Models.Drivers.Contracts;

    public class DriverRepository : Repository<IDriver>
    {
        public object OrderBy { get; internal set; }

        public override void Add(IDriver model)
        {
            this.collection.Add(model.Name, model);
        }

        public override IDriver GetByName(string name)
            => this.collection[name];

        public override bool Remove(IDriver model) 
            => this.collection.Remove(model.Name);
    }
}
