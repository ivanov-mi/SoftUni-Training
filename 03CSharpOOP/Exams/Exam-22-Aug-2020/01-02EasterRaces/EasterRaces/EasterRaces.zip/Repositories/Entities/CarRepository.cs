﻿namespace EasterRaces.Repositories.Entities
{
    using EasterRaces.Models.Cars.Contracts;

    public class CarRepository : Repository<ICar>
    {
        public override void Add(ICar model)
        {
            this.collection.Add(model.Model, model);
        }

        public override ICar GetByName(string name)
            => this.collection[name];

        public override bool Remove(ICar model) 
            => this.collection.Remove(model.Model);
    }
}
